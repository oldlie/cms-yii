<?php

/* @var $this yii\web\View */

?>

<div class="mod3 container clearfix">
    <div class="row">
        <div class="col-md-4 col-sm-6">
            产品1
        </div>
        <div class="col-md-4 col-sm-6">
            产品2
        </div>
        <div class="col-md-4 col-sm-6">
            产品3
        </div>
        <div class="col-md-4 col-sm-6">
            产品4
        </div>
    </div>
</div>